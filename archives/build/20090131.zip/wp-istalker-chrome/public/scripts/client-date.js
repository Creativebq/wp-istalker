wpi.date = new Date();
if (wpi.date.getDate() >= 24 && wpi.date.getMonth() == 11 ){ jQuery.getScript(wpi.theme_url + "snow.js", function(){ return; });};